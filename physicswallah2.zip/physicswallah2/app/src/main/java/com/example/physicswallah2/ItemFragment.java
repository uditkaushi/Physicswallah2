package com.example.physicswallah2;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.physicswallah2.dummy.DummyContent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class ItemFragment extends Fragment implements MyItemRecyclerViewAdapter.sendmessage  {

    List<String> item;
    MyItemRecyclerViewAdapter recyclerViewAdapter;
    RecyclerView recyclerView;
    boolean[] z=new boolean[10];
    int count=0,i;

    String[] n=new String[10];

    @Override
    public void sendingmessage(String string,boolean c) {
        z[count]=c;
        n[count]=string;
        for(i=0;i<count;i++){
            if(n[i].equals(string)){
                z[i]=c;
                count--;
            }
        }
        count++;


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_item_list, container, false);


        Arrays.fill(z,false);

        item= new ArrayList<>();
        item.add("Italy");
        item.add("Rome");
        item.add("Varanasi");
        item.add("Moscow");

        recyclerViewAdapter=new MyItemRecyclerViewAdapter(this, item);
        recyclerView= view.findViewById(R.id.list);
        recyclerView.setAdapter(recyclerViewAdapter);
        return view;
    }


    public void updateagain(boolean a){
        for(int j=0;j<count;j++) {
            if (z[j] && a) {
                item.remove(n[j]);
            }
        }
        a = false;
        recyclerViewAdapter = new MyItemRecyclerViewAdapter(this, item);
        recyclerView.setAdapter(recyclerViewAdapter);

    }
    public void updateedittext(String newtext,boolean c){
        item.add(newtext);
        recyclerViewAdapter=new MyItemRecyclerViewAdapter(this,item);
        recyclerView.setAdapter(recyclerViewAdapter);
    }


}