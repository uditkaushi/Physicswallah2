package com.example.physicswallah2;

import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.physicswallah2.dummy.DummyContent.DummyItem;

import java.util.ArrayList;
import java.util.List;

public class MyItemRecyclerViewAdapter extends RecyclerView.Adapter<MyItemRecyclerViewAdapter.ViewHolder> {

    private final List<String> mValues;
    sendmessage sendmessage;
    List<String>listi;

    public MyItemRecyclerViewAdapter(sendmessage sendmessage, List<String> mValues) {
        this.mValues = mValues;
        this.sendmessage=sendmessage;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_item, parent, false);

        return new ViewHolder(view,sendmessage);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mIdView.setText(mValues.get(position));
        listi=new ArrayList<>();
        holder.mIdView.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){

                    sendmessage.sendingmessage(compoundButton.getText().toString(),b);
                }
                else{
                    sendmessage.sendingmessage(compoundButton.getText().toString(),b);
                }

            }
        });
    }

    @Override
    public int getItemCount() {

        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final CheckBox mIdView;
        sendmessage sendmessage;
        public ViewHolder(View view,sendmessage sendmessage) {
            super(view);
            this.sendmessage=sendmessage;
            mView = view;
            mIdView =  view.findViewById(R.id.checkBox);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mIdView.getText() + "'";
        }
    }

    public interface sendmessage{
        void sendingmessage(String string,boolean c);
    }

    
}