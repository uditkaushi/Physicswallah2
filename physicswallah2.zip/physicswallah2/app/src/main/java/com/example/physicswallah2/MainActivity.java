package com.example.physicswallah2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements buttonFragment.OnMessageSendListener {

    buttonFragment buttonFragment;
    ItemFragment itemFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonFragment=new buttonFragment();
        itemFragment=new ItemFragment();

        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout2,buttonFragment,null).replace(R.id.frameLayout1,itemFragment,null).commit();
    }

    @Override
    public void onMessageSend(String message,boolean c) {

        Toast.makeText(MainActivity.this,message,Toast.LENGTH_SHORT).show();

        itemFragment.updateedittext(message,c);
    }

    @Override
    public void newmessagegoo(boolean b) {
        itemFragment.updateagain(b);
    }



}