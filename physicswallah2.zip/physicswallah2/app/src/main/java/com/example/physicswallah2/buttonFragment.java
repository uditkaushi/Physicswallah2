package com.example.physicswallah2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.OnNmeaMessageListener;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;


public class buttonFragment extends Fragment {

    Button add;
    Button delete;
    EditText text;
    String matter;
    OnMessageSendListener messageSendListener;
    List<String> items;
    boolean a;

    public interface OnMessageSendListener{
        void onMessageSend(String message,boolean c);
        void newmessagegoo(boolean b);
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_button, container, false);
        add=view.findViewById(R.id.button);
        delete=view.findViewById(R.id.button2);
        text =view.findViewById(R.id.editText);
        a=false;

        items=new ArrayList<>();

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                matter= text.getText().toString();

                messageSendListener.onMessageSend(matter,a);

            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a=true;
                messageSendListener.newmessagegoo(a);
            }
        });


        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        Activity activity=(Activity) context;
        try {
            messageSendListener=(OnMessageSendListener) activity;
        }
        catch (ClassCastException e){
            throw new ClassCastException(activity.toString()+"must implement onMessageSend");
        }
    }



    @Override
    public void onDetach() {
        super.onDetach();
        messageSendListener=null;
    }
}